import os

# Ruta de la carpeta principal que contiene las subcarpetas
main_folder = 'Face_re'  # Reemplaza con la ruta correcta

# Recorrer cada subcarpeta
for dir_name in os.listdir(main_folder):
    subdir_path = os.path.join(main_folder, dir_name)
    
    # Solo procedemos si es una carpeta
    if os.path.isdir(subdir_path):
        for idx, file_name in enumerate(os.listdir(subdir_path), start=1):
            # Obtener la extensión del archivo
            file_ext = os.path.splitext(file_name)[1]
            # Crear el nuevo nombre de archivo con el nombre de la carpeta seguido de un número
            new_name = f"{dir_name}_{idx}{file_ext}"
            # Ruta completa del archivo original y el nuevo archivo
            original_file_path = os.path.join(subdir_path, file_name)
            new_file_path = os.path.join(subdir_path, new_name)
            # Renombrar el archivo
            os.rename(original_file_path, new_file_path)
            print(f"Renombrado: {original_file_path} -> {new_file_path}")

print("Renombrado completo.")
